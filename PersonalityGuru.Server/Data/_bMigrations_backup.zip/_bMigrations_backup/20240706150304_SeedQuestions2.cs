﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PersonalityGuru.Migrations
{
    /// <inheritdoc />
    public partial class SeedQuestions2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_AspNetUserClaims_AspNetUsers_UserName",
            //    table: "AspNetUserClaims");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_AspNetUserLogins_AspNetUsers_UserName",
            //    table: "AspNetUserLogins");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_AspNetUserRoles_AspNetUsers_UserName",
            //    table: "AspNetUserRoles");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_AspNetUserTokens_AspNetUsers_UserName",
            //    table: "AspNetUserTokens");

            //migrationBuilder.RenameColumn(
            //    name: "UserName",
            //    table: "AspNetUserTokens",
            //    newName: "UserId");

            //migrationBuilder.RenameColumn(
            //    name: "UserName",
            //    table: "AspNetUserRoles",
            //    newName: "UserId");

            //migrationBuilder.RenameColumn(
            //    name: "UserName",
            //    table: "AspNetUserLogins",
            //    newName: "UserId");

            //migrationBuilder.RenameIndex(
            //    name: "IX_AspNetUserLogins_UserName",
            //    table: "AspNetUserLogins",
            //    newName: "IX_AspNetUserLogins_UserId");

            //migrationBuilder.RenameColumn(
            //    name: "UserName",
            //    table: "AspNetUserClaims",
            //    newName: "UserId");

            //migrationBuilder.RenameIndex(
            //    name: "IX_AspNetUserClaims_UserName",
            //    table: "AspNetUserClaims",
            //    newName: "IX_AspNetUserClaims_UserId");

            migrationBuilder.AddColumn<string>(
                name: "FullName",
                table: "AspNetUsers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 1,
                column: "Text",
                value: "Я вижу красоту и смыслы там, где другие их не видят");

            migrationBuilder.UpdateData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 2,
                column: "Text",
                value: "Если человек мне не нравится, я не восприму его аргументы впринципе");

            migrationBuilder.UpdateData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Group", "Text" },
                values: new object[] { "К", "Я ценю чистоту и порядок по всем" });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "Id", "Group", "InvertedScore", "TestId", "Text" },
                values: new object[,]
                {
                    { 4, "К", true, 1, "Я редко читаю что-либо о самоорганизации и менеджменте времени" },
                    { 5, "Е", false, 1, "Мне нравится чувствовать адреналин" },
                    { 6, "Е", false, 1, "Я довольно быстро и громко говорю" },
                    { 7, "А", false, 1, "Я могу пожертвовать своими интересами и временем ради других" },
                    { 8, "А", false, 1, "Мне неспокойно, когда другие чувствуют себя плохо" },
                    { 9, "Н", false, 1, "Я часто прокручиваю в голове слова людей, которые меня задели" },
                    { 10, "Н", false, 1, "Я часто представляю худший сценарий" }
                });

            //migrationBuilder.AddForeignKey(
            //    name: "FK_AspNetUserClaims_AspNetUsers_UserId",
            //    table: "AspNetUserClaims",
            //    column: "UserId",
            //    principalTable: "AspNetUsers",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_AspNetUserLogins_AspNetUsers_UserId",
            //    table: "AspNetUserLogins",
            //    column: "UserId",
            //    principalTable: "AspNetUsers",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                table: "AspNetUserRoles",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                table: "AspNetUserTokens",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_AspNetUserClaims_AspNetUsers_UserId",
            //    table: "AspNetUserClaims");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_AspNetUserLogins_AspNetUsers_UserId",
            //    table: "AspNetUserLogins");

            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                table: "AspNetUserRoles");

            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                table: "AspNetUserTokens");

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DropColumn(
                name: "FullName",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "AspNetUserTokens",
                newName: "UserName");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "AspNetUserRoles",
                newName: "UserName");

            //migrationBuilder.RenameColumn(
            //    name: "UserId",
            //    table: "AspNetUserLogins",
            //    newName: "UserName");

            //migrationBuilder.RenameIndex(
            //    name: "IX_AspNetUserLogins_UserId",
            //    table: "AspNetUserLogins",
            //    newName: "IX_AspNetUserLogins_UserName");

            //migrationBuilder.RenameColumn(
            //    name: "UserId",
            //    table: "AspNetUserClaims",
            //    newName: "UserName");

            //migrationBuilder.RenameIndex(
            //    name: "IX_AspNetUserClaims_UserId",
            //    table: "AspNetUserClaims",
            //    newName: "IX_AspNetUserClaims_UserName");

            migrationBuilder.UpdateData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 1,
                column: "Text",
                value: "q1");

            migrationBuilder.UpdateData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 2,
                column: "Text",
                value: "q2");

            migrationBuilder.UpdateData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Group", "Text" },
                values: new object[] { "O", "q3" });

            //migrationBuilder.AddForeignKey(
            //    name: "FK_AspNetUserClaims_AspNetUsers_UserName",
            //    table: "AspNetUserClaims",
            //    column: "UserName",
            //    principalTable: "AspNetUsers",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_AspNetUserLogins_AspNetUsers_UserName",
            //    table: "AspNetUserLogins",
            //    column: "UserName",
            //    principalTable: "AspNetUsers",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUserRoles_AspNetUsers_UserName",
                table: "AspNetUserRoles",
                column: "UserName",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUserTokens_AspNetUsers_UserName",
                table: "AspNetUserTokens",
                column: "UserName",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
